<template>
  <div class="home">
    <h1>Sujin Jo</h1>
  </div>
</template>

<script>

export default {
  name: 'HomeView'
}
</script>
